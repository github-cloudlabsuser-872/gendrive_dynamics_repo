import time
import uuid
import json


class Message:
    def __init__(self, role, content, visible=True, image_upload_request=False):
        self.timestamp = int(time.time()*1000)
        self.role = role
        self.raw_content = content
        self.visible = visible
        self.image_upload_request = image_upload_request
        self.structured_content = {}
        if isinstance(content, str):
            self._parse_agent_response()
        elif isinstance(content, dict):
            self._parse_user_input()

    def _parse_agent_response(self):
        try:
            self.raw_content = self.raw_content.replace("\n", '')
            response_parsed = json.loads(self.raw_content)
        except json.decoder.JSONDecodeError as e:
            print(e)
            response_parsed = {}
        self.structured_content = response_parsed
        self.step = response_parsed.get('Step', '')
        self.chat_text = response_parsed.get('Response to User', '')
        vehicle_info = response_parsed.get('Vehicle Information', {'Vehicle Brand': 'unknown', 'Vehicle Model': 'unknown'})
        self.vehicle_brand = vehicle_info.get('Vehicle Brand', 'unknown')
        self.vehicle_model = vehicle_info.get('Vehicle Model', 'unknown')
        self.damage_assessment = response_parsed.get('Damage Assessment', [])
        self.needed_actions = response_parsed.get('Needed Actions', [])
        self.image = None

    def _parse_user_input(self):
        self.structured_content = self.raw_content
        self.chat_text = self.raw_content.get('chat_text', '')
        self.prompt = self.raw_content.get('prompt', '')
        self.image = self.raw_content.get('image', None)

class ChatHistory:
    def __init__(self, roles:list=[]):
        """
        Class ChatHistory represents a chat history between the agent and the user.
        """
        self.roles = roles
        self.messages = {}
        self.session_id = str(uuid.uuid4())

    def add_message(self, message):
        """
        Adds a message to the message history.
        """
        self.messages[message.timestamp] = message
        
    def add_image_to_last_message(self, image):
        """
        Attaches an image to the last message in the chat history.
        """
        last_msg_key = list(self.messages.keys())[-1]
        self.messages[last_msg_key].image = image

    def get_last_ai_message(self):
        """
        Get the last ai message.
        """
        if len(self.messages)==0:
            return None
        for msg in reversed(self.messages.values()):
            if msg.role=='Claire':
                return msg
            
    def get_last_user_message(self):
        """
        Get the last user message.
        """
        if len(self.messages)==0:
            return None
        for msg in reversed(self.messages.values()):
            if msg.role=='Emily':
                return msg
