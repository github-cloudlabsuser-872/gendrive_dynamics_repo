from vertexai.generative_models import (
    FunctionDeclaration,
    GenerativeModel,
    Part,
    Tool,
    GenerationResponse,
    Image
)


# define functions that are included in the model

def get_product_sku(**kwargs):
    print(f'function called: get_product_sku')
    print(kwargs)
    return {"sku": "GA04834-US", "in_stock": "yes"}

get_product_info_func = FunctionDeclaration(
    name="get_product_sku",
    description="Get the SKU for a product",
    # Function parameters are specified in OpenAPI JSON schema format
    parameters={
        "type": "object",
        "properties": {
            "product_name": {"type": "string", "description": "Product name"}
        },
    },
)


def get_store_location(**kwargs):
    print(f'function called: get_store_location')
    print(kwargs)
    return {"store": "2000 N Shoreline Blvd, Mountain View, CA 94043, US"}

get_store_location_func = FunctionDeclaration(
    name="get_store_location",
    description="Get the location of the closest store",
    # Function parameters are specified in OpenAPI JSON schema format
    parameters={
        "type": "object",
        "properties": {"location": {"type": "string", "description": "Location"}},
    },
)


def create_customer_profile(**kwargs):
    print(f'function called: create_customer_profile')
    print(kwargs)
    is_empty = []
    for arg, value in kwargs.items():
        if value is None or value == '':
            is_empty.append(arg)
    if is_empty:
        return {"response": "customer creation unsucessful", "missing values": f"Provide missing information: {is_empty}"}
    return {"response": "customer created"}

create_customer_profile_func = FunctionDeclaration(
    name="create_customer_profile",
    description="Create customer profile",
    # Function parameters are specified in OpenAPI JSON schema format
    parameters={
        "type": "object",
        "properties": {
            "name": {"type": "string", "description": "Name of customer"},
            "mail": {"type": "string", "description": "mail of customer"},
            "address": {"type": "string", "description": "address of customer"},
        },
        "required": ["name", "mail", "address"]
    },
)


# Define a tool that includes the above functions
retail_tool = Tool(
    function_declarations=[
        get_product_info_func,
        get_store_location_func,
        create_customer_profile_func
    ],
)
