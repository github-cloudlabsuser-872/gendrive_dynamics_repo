import base64
import time
import pandas as pd
import json

import vertexai
from vertexai.generative_models import (
    GenerativeModel,
    Part,
    Tool,
    GenerationResponse,
    Image
)
from vertexai.preview.generative_models import grounding

from src.chat_history import ChatHistory, Message

PROJECT_ID = "cap-al-genies"
REGION = "us-central1"
vertexai.init(project=PROJECT_ID, location=REGION)


class Claire:
    def __init__(self,  system_prompt_file: str, model_configs_file: str, cost_estimation_prompt_file: str, image_damage_assessment_prompt_file: str):
        """
        This class represents the car repair agent chat bot for a post accident car damage estimation.
        """
        with open(system_prompt_file, "r") as file:
            self.system_prompt = file.read()

        with open(model_configs_file, "r") as file:
            self.model_config = json.load(file)

        with open(cost_estimation_prompt_file, "r") as file:
            self.cost_estimation_prompt = file.read()

        with open(image_damage_assessment_prompt_file, "r") as file:
            self.image_damage_assessment_prompt = file.read()

        self.model = GenerativeModel(
            "gemini-1.0-pro-vision",
            generation_config=self.model_config
        )

        self.session_id = str(time.time()*1000)

        self.agent_name = 'Claire'
        self.user_name = 'Emily'
        self.history = ChatHistory(roles=[self.agent_name, self.user_name])
        self.chat = self.model.start_chat()
        self.damage_overview = pd.DataFrame(columns=['Component', 'Position', 'Damage Type', 'Severity', 'Repair Type'])
        self.cost_overview = pd.DataFrame(columns=['Component', 'Position', 'Damage Type', 'Severity', 'Repair Type', 'Labour Cost', 'Part Cost'])
        self.car_manufacturer = 'unknown'
        self.car_model = 'unknown'

        self.cae = CostAssessmentEngine(prompt=self.cost_estimation_prompt)
        print(f'Claire successfully set up\n{system_prompt_file = }\n{self.model_config = }\n')
       
    def send_message(self, user_input: str, visible_in_chat: bool = True) -> Message:
        """
        Send a text message to the chat agent.
        """
        prompt = self.system_prompt.replace("{Input}", user_input)
        last_ai_message = self.history.get_last_ai_message()
        if last_ai_message:
            prompt = prompt.replace("{Output}", last_ai_message.raw_content)
        else:
            prompt = prompt.replace("{Output}", '')
        
        last_user_message = self.history.get_last_user_message()
        if last_user_message and last_user_message.image:
            prompt = prompt.replace("{Image}", last_user_message.chat_text)
        print(f'USER: {prompt}')
        message = Message(role=self.user_name,
                          content={'chat_text': user_input,
                                   'prompt': prompt,
                                   'image': None},
                        visible=visible_in_chat)
        self.history.add_message(message)

        try:
            response = self.chat.send_message(prompt)
            if len(response.candidates) > 1:
                print(f'Warning: More than one response candidate detected\n{response.candidates = }')

            raw_response = response.candidates[0].content.parts[0].text
            message = Message(role=self.agent_name, content=raw_response)

            if last_user_message and last_user_message.image:
                damage_description = self.history.get_last_user_message().chat_text
                message.chat_text += f' {damage_description}'

            self.history.add_message(message)
            self.update_vehicle_information()
            self.update_damage_estimation()
            print(f'AI: {raw_response}')
            return message
        
        except Exception as exc:
            message = Message(role=self.agent_name,
                              content=f"{{'Response to User': '{exc}'}}")
            self.history.add_message(message)
            return message
        
    def send_image_to_assess_damages(self, image):
        """
        Send an image to the agent to estimate visual damages.
        """
        try:
            encoded_image = image.split(",")[1]
            decoded_image = base64.b64decode(encoded_image)
            image = Image.from_bytes(decoded_image)
            response = self.model.generate_content([image, self.image_damage_assessment_prompt])
            if len(response.candidates) > 1:
                print(f'Warning: More than one response candidate detected\n{response.candidates = }')

            damage_raw_response = response.candidates[0].content.parts[0].text
            self.send_message(damage_raw_response, visible_in_chat = False)
        
        except Exception as exc:
            message = Message(role=self.agent_name,
                              content=f"{{'Response to User': '{exc}'}}")
            self.history.add_message(message)
            return message
    
    def update_vehicle_information(self):
        """
        Updates the vehicle information based on the last message from the agent
        """
        msg = self.history.get_last_ai_message()
        if msg:
            self.car_manufacturer = msg.vehicle_brand
            self.car_model = msg.vehicle_model

    def update_damage_estimation(self):
        """
        Updates the damage estimation based on the last message from the agent
        """
        msg = self.history.get_last_ai_message()
        if msg:
            self.damage_overview = pd.DataFrame(msg.damage_assessment)

    def update_cost_estimation(self):
        """
        Updates the cost estimation based on the collected damages
        """
        try:
            msg = self.history.get_last_ai_message()
            vehicle_information = {'Vehicle Brand': msg.vehicle_brand, 'Vehicle Model': msg.vehicle_model}
            damage_information = self.damage_overview
            cost_estimation = self.cae.estimate_cost(vehicle_information, damage_information.to_dict('records'))
            cost_table_df = pd.DataFrame(cost_estimation)
            self.cost_overview = cost_table_df
        except:
            cost_table_df = pd.DataFrame(columns=['Component', 'Position', 'Damage Type', 'Severity', 'Repair Type', 'Labour Cost', 'Part Cost'])
            self.cost_overview = cost_table_df

    def get_damage_estimation(self):
        """
        Returns a damage estimation table as pd.DataFrame
        """
        return self.damage_overview
    
    def get_cost_estimation(self):
        """
        Updates the cost estimation and returns it as pd.DataFrame
        """
        self.update_cost_estimation()
        return self.cost_overview
    
    def replace_damage_estimation(self, damage_estimation: pd.DataFrame):
        """
        Replaces the damage estimation with one provided by the user
        """
        self.damage_overview = damage_estimation

    def replace_cost_estimation(self, cost_estimation: pd.DataFrame):
        """
        Replaces the cost estimation with one provided by the user
        """
        self.cost_overview = cost_estimation


class CostAssessmentEngine:
    def __init__(self, prompt, data_store_id:str=None):
        """
        Cost estimation engine uses VERTEX AI Conversation to estimate costs based on the information from data stores and damage overview provided by the user
        """
        self.model = GenerativeModel(model_name="gemini-1.0-pro")
        self.prompt = prompt

        # Create Tool for grounding
        if data_store_id:
            # Use Vertex AI Search data store
            data_store_path = f'projects/{PROJECT_ID}/locations/{REGION}/collections/default_collection/dataStores/{data_store_id}'
            self.tool = Tool.from_retrieval(
                grounding.Retrieval(grounding.VertexAISearch(datastore=data_store_path))
            )
        else:
            # Use Google Search for grounding (Private Preview)
            self.tool = Tool.from_google_search_retrieval(grounding.GoogleSearchRetrieval())

    def estimate_cost(self, vehicle_information:list, damage_information:list) -> dict:
        """
        Provides a cost estimation based on the vehicle information and damage description
        """
        prompt = self.prompt.replace('{vehicle_information}', str(vehicle_information))
        prompt = self.prompt.replace('{damage_information}', str(damage_information))          
        response = self.model.generate_content(prompt, tools=[self.tool])
        response_text = response.candidates[0].content.parts[0].text
        try:
            response_parsed = json.loads(response_text)
            print(response_parsed)
            return response_parsed
        except json.decoder.JSONDecodeError as e:
            print(e)
            return response_text
