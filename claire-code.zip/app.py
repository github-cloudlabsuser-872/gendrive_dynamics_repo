import time
import pandas as pd

import dash
from dash import dcc, html, dash_table, Dash
from dash import Input, Output, State, callback
import dash_bootstrap_components as dbc

from src.Claire import Claire
from src.chat_history import Message
from datetime import datetime


### CLAIRE INITIALISATION
claire = Claire(
    system_prompt_file='prompts/system_prompt_v1.txt',
    cost_estimation_prompt_file='prompts/cost_estimation_v0.txt',
    image_damage_assessment_prompt_file='prompts/image_prompt_v0.txt',
    model_configs_file='config.json',
)


### APPLICATION INITIALISATION
app = Dash('__name__',
           title='CLAIRE',
           external_stylesheets=['https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap',
                                 'https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200'],
           suppress_callback_exceptions=True,
           )


### APP LAYOUT

# Image upload button
upload_btn = html.Div(id='upload-btn-div', children=[
                dcc.Upload(
                    id='upload-image-btn',
                    children=html.Div('Use image to describe damages'),
                    style={
                        'width': '100%',
                        'height': '60px',
                        'lineHeight': '60px',
                        'borderWidth': '1px',
                        'borderStyle': 'dashed',
                        'borderRadius': '5px',
                        'textAlign': 'center',
                        'margin': '10px'
                    },
                    multiple=False
                    )]
                )

# Chat section
chat_section = html.Div([
    html.Div([
        html.Div([],id='chat-output'),

        html.Div([
            html.Div([
                dbc.Input(id='chat-textinput',
                          type='text',
                          #name='chat-txt',
                          placeholder='Add a Message...'),
                #dbc.Button('image', className='btn-attach material-symbols-outlined'),
                #dbc.Button('mic', className='btn-record material-symbols-outlined')
            ], className='input-wrapper'),
            dbc.Button('send', className='btn-primary material-symbols-outlined', id='submit')
        ], id='chat-input')

    ], id='chat-section',)
    ], className='column')

# Reset input field callback
@callback(
    Output("chat-textinput", "value"),
    [Input("submit", "n_clicks"), Input("chat-textinput", "n_submit")],
)
def reset_input_field(n_clicks, n_submit):
    return ""

# Submit button callback
@callback(
    Output("chat-update-trigger-text-submit", "data"),
    Input("submit", "n_clicks"),
    Input("chat-textinput", "n_submit"),
    State("chat-textinput", "value"),
    prevent_initial_call = True
)
def submit_text(n_clicks, n_submit, user_input):
    if (n_clicks == 0) and (n_submit is None):
        return time.time()

    if (user_input is None) or (user_input == ""):
        return time.time()

    # Image request triggered by user
    if user_input=='Image':
        upload_image_msg = Message(role=claire.user_name,
                                   content={},
                                   image_upload_request=True,
                                   visible=True)
        claire.history.add_message(upload_image_msg)
        return time.time()
    
    claire.send_message(user_input)
    return time.time()

# In-chat upload image button callback
@callback(Output('output-image-upload', 'children'),
          Output('upload-btn-div', 'children'),
          Output('chat-update-trigger-image-upload', 'data'),
        Input('upload-image-btn', 'contents'),
        State('upload-image-btn', 'filename'),
        prevent_initial_call=True,
        suppress_callback_exceptions=True)
def upload_image(image, filename):
    if image is not None:
        image_thumbnail = html.Div('Click to upload an image')
        claire.history.add_image_to_last_message(image)
        claire.send_image_to_assess_damages(image)
        return image_thumbnail, None, time.time()

# Update chat callback
@callback(Output("chat-output", "children"),
        Input('chat-update-trigger-text-submit', 'data'),
        Input('chat-update-trigger-image-upload', 'data'))
def update_chat(trigger_text_submit, trigger_image_upload):
    return html_chat()

# Creates a single chat bubble
def html_element(role, time, text, image=None, include_image_upload_btn=False):
    if role == 'AI':
        message = html.Div([
            html.Div([
                html.Span(
                    html.Img(src=dash.get_asset_url('Chat-AI.png'))
                ),
                html.Span(time, className='text-small')
            ], className='message-header'),
            html.Div(
                html.P(text)
            , className='message-body')
        ], className='message message-claire')
    elif role == 'user':
        if include_image_upload_btn and image is None:
            message_content = [upload_btn, html.Div(id='output-image-upload')]
        elif include_image_upload_btn==False and image:
            message_content = html.Img(src=image)
        else:
            message_content = text

        message = html.Div([
            html.Div([
                html.Span(html.Img(src=dash.get_asset_url('Chat-User.png'))),
                html.Span(time, className='text-small')
            ], className='message-header'),

            html.Div(message_content, className='message-body')
        ], className='message message-user')
    return message

# Build a chat history from chat bubbles
def html_chat():
    message_comps = []
    for message in claire.history.messages.values():
        if message.visible==False:
            continue

        if message.role == claire.user_name:
            if message.image_upload_request and (message.image is None):
                message_comps.append(html_element(role="user",
                                             time=datetime.fromtimestamp(message.timestamp/1000).strftime("%H:%M:%S"),
                                             text=message.chat_text,
                                             include_image_upload_btn=message.image_upload_request))
            elif message.image:
                message_comps.append(html_element(role="user",
                                             time=datetime.fromtimestamp(message.timestamp/1000).strftime("%H:%M:%S"),
                                             text=message.chat_text,
                                             image=message.image))
            else:
                message_comps.append(html_element(role="user",
                                             time=datetime.fromtimestamp(message.timestamp/1000).strftime("%H:%M:%S"),
                                             text=message.chat_text))
        elif message.role == claire.agent_name:
            message_comps.append(html_element(role="AI",
                                time=datetime.fromtimestamp(message.timestamp/1000).strftime("%H:%M:%S"),
                                text=message.chat_text))
    return message_comps


# Creates a damage overview table
def build_damage_table(damage_estimation):
    table = dash_table.DataTable(                    
                    damage_estimation.to_dict('records'), [{"name": i, "id": i} for i in damage_estimation.columns],
                    id='damage-table',
                    editable=True,
                    row_deletable=True,
                    )
    
    return table

# Damage overview update callback
@callback(Output('damage-table-section','children'),
          Input('chat-output', 'children'),
          prevent_initial_call=True)
def update_damage_table_section(chat_output):
    damage_estimation = claire.get_damage_estimation()
    if damage_estimation.empty:
        return html.Div([html.H1('Damage overview'),
                         html.Span('info', className='material-symbols-outlined icon-info-message'),
                         html.Div('The damage estimation becomes availabe as soon as you describe the damage to Claire in the chat.', id='info-message')])
    
    damage_table = build_damage_table(damage_estimation)
    damage_table_section = html.Div([
                html.H1('Damage overview'),
                html.Span('add', className='material-symbols-outlined icon-add-costs'),
                html.Button('Add Damages', id='add-damage-button', n_clicks=0),
                html.Div(damage_table, id='damage-data-table'),
                html.Br(),
                html.Br(),
                html.Button('Calculate Costs', id='calculate-cost-button'),
                html.Br(),
                html.Div([ html.Div(id='cost-table-view', children=[])
        ], className="row"),
        ])
    return damage_table_section

# Add row to damage table callback
@callback(
    Output('damage-table', 'data'),
    Input('add-damage-button', 'n_clicks'),
    State('damage-table', 'data'),
    State('damage-table', 'columns'))
def add_damage_row(n_clicks, current_data, columns):
    if n_clicks > 0:
        current_data.append({c['id']: '' for c in columns})
        print(current_data)
    return current_data

# Damage overview table content update callback
@callback(
    Output('damage-table-update', 'data'),
    Input('damage-table', 'data'),
    prevent_initial_call=True)
def update_damage_overview(rows):
    claire.replace_damage_estimation(pd.DataFrame(rows))
    return None

# Creates a cost overview table
def build_cost_table(cost_estimation):
    table = dash_table.DataTable(
                    cost_estimation.to_dict('records'), [{"name": i, "id": i} for i in cost_estimation.columns],
                    id='cost-table',
                    editable=True,
                    row_deletable=True,
                    )
    
    return table

# Add row to cost overview table callback
@callback(
    Output('cost-table', 'data'),
    Input('add-costs-button', 'n_clicks'),
    State('cost-table', 'data'),
    State('cost-table', 'columns'))
def add_cost_row(n_clicks, rows, columns):
    if n_clicks > 0:
        rows.append({c['id']: '' for c in columns})
    return rows

# Calculate cost button callback
@callback(Output('cost-table-section','children'),
          Input('calculate-cost-button', 'n_clicks'),
          prevent_initial_call=True)
def update_cost_table_section(n_clicks):
    if n_clicks is None:
        return []
    cost_estimation = claire.get_cost_estimation()
    cost_table = build_cost_table(cost_estimation)
    cost_table_section = html.Div([
                html.H1('Cost overview'),
                html.Span('add', className='material-symbols-outlined icon-add-costs'),
                html.Button('Add Costs', id='add-costs-button', n_clicks=0),
                html.Div(cost_table, id='cost-data-table'),
                html.Br(),
                html.Br(),
                html.Button('Complete', className='btn-primary', id='complete-button', n_clicks=0),
                html.Div(id='estimation-completed-msg')])
    return cost_table_section

# Complete message
complete_message = [html.Br(),
                html.Span('check_circle', className='material-symbols-outlined icon-success-message'),
                html.Div('You successfully created the repair estimation and sent it to the insurance company', id='success-message')]

# Cost overview table content update callback
@callback(
    Output('cost-table-update', 'data'),
    Input('cost-table', 'data'),
    Input('cost-table', 'columns'),
    prevent_initial_call=True)
def update_cost_overview(rows, columns):
    claire.replace_cost_estimation(pd.DataFrame(rows))
    return None

# Complete button
@callback(
    Output('estimation-completed-msg', 'children'),
    Input('complete-button', 'n_clicks'),
    prevent_initial_call=True)
def show_msg(n_clicks):
    return complete_message

# Section with damage and cost overview tables
tables_section = html.Div([html.H1('Vehicle information'),
                            html.Div(id='vehicle-information'),
                            html.Div(id='damage-table-section'),
                           html.Div(id='cost-table-section')],
                           className='column')

# Header
header = html.Div([
    html.Img(src=dash.get_asset_url('Logo.png'), className='logo'),
    html.Div([
        html.Img(src=dash.get_asset_url('User-Loggedin.png')),
        html.Span('Emily Miller', className='text-reg')
    ], className='user-login')
    ],
    id='header')


vehicle_section = html.Div([html.H1('Vehicle information'),
                            html.Div(id='vehicle-information')
                            ])

# Vehicle information update callback
@callback(Output('vehicle-information','children'),
          Input('chat-output', 'children'))
def update_vehicle_section(chat_output):
    return html.Div(f'Brand: {claire.car_manufacturer}, Model: {claire.car_model}')

### APP LAYOUT
body = html.Div([
        chat_section,
 #       vehicle_section,
        tables_section,
        dcc.Store(id='chat-update-trigger-image-upload'),
        dcc.Store(id='chat-update-trigger-text-submit'),
        dcc.Store(id='damage-table-update'),
        dcc.Store(id='cost-table-update')
    ], className='row')
app.layout = html.Div([header,body])


if __name__ == '__main__':
    app.run(debug=False)