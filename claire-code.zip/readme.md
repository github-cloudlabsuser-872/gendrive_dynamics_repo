# Claire: Multi-Agent Car Damage Estimation Application

Claire is a multi-agent application designed to estimate car damage by leveraging chatbot interaction, damage classification, and repair cost estimation engines. The application facilitates seamless communication between users and the backend services for efficient data collection, damage analysis, and cost prediction.

## Getting Started

To set up the Claire application locally, follow these steps:
   - Complete a GCP authorization on your target platform using [the official google manual](https://cloud.google.com/sdk/docs/authorizing).
   - Install Python dependencies using `pip install -r requirements.txt`.
   - Run the claire application using `python app.py`.

By default the app will be running on [127.0.0.1:8050](http://127.0.0.1:8050).


## Customization

To customize the app, you can update the file config.json or update and link the prompts that can be found in folder prompts.

## License

This project is licensed under the [MIT License](LICENSE), which allows for free use, modification, and distribution of the software.

## Acknowledgments

- Special thanks to the contributors and developers who have contributed to the Claire project.
- This project was inspired by the need for efficient car damage estimation solutions in the automotive industry.
- Super specical thanks to you, reading all the way to the end
- And to ChatGPT, the genious that created this readme
